package Project;

import java.util.Random;

public class AI {
    public static void randomChoose(int[][] board, int[][] state,int c) {
        int[] v = {0, 1, 2, 3, 4, 5, 6, 7};
        int[] h = {0, 1, 2, 3};
        Random r1 = new Random();
        for (int i = 0; i < 8; i++) {
            int index = r1.nextInt(8);
            int temp = v[index];
            v[index] = v[i];
            v[i] = temp;
        }
        Random r2 = new Random();
        for (int i = 0; i < 4; i++) {
            int index = r2.nextInt(4);
            int temp = h[index];
            h[index] = h[i];
            h[i] = temp;
        }
        int x = -1;
        int y = -1;
        define:
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 4; j++) {
                if (randomChooseJudge(v[i], h[j], board, state,c)) {
                    x = v[i];
                    y = h[j];
                    break define;
                }
            }
        }
        if (state[x][y] != 0 && board[x][y] != 7) {
            randomChooseMove(x, y, board, state);
        }
        if(state[x][y] != 0 && board[x][y] == 7){
            randomChooseCannon(x,y,board,state);
        }
        if (state[x][y] == 0) {
            randomChooseTurn(x, y, board, state);
        }

    }


    public static boolean randomChooseJudge(int x, int y, int[][] board, int[][] state,int c) {
        boolean r = false;
        int n = 0;
        if (state[x][y] == 0) {
            n = 1;
        }
        if (Math.abs(board[x][y]) != 7) {
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 4; j++) {
                    if (MoveJudge.mj(x, y, i, j, board, state)) {
                        n = 1;
                    }
                }
            }
        }
        if (Math.abs(board[x][y]) == 7) {
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 4; j++) {
                    if (CannonJudge.cj(x, y, i, j, board, state)) {
                        n = 1;
                    }
                }
            }
        }
        if(board[x][y]*c>0){
            n = 0;
        }
        if (n == 1) {
            r = true;
        }
        return r;
    }

    public static void abRandomChoose(int[][] board, int[][] state,int c) {
        int[] v = {0, 1, 2, 3, 4, 5, 6, 7};
        int[] h = {0, 1, 2, 3};
        Random r1 = new Random();
        for (int i = 0; i < 8; i++) {
            int index = r1.nextInt(8);
            int temp = v[index];
            v[index] = v[i];
            v[i] = temp;
        }
        Random r2 = new Random();
        for (int i = 0; i < 4; i++) {
            int index = r2.nextInt(4);
            int temp = h[index];
            h[index] = h[i];
            h[i] = temp;
        }
        int x = -1;
        int y = -1;
        define:
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 4; j++) {
                if (abRandomChooseJudge(v[i], h[j], board, state,c)) {
                    x = v[i];
                    y = h[j];
                    break define;
                }
            }
        }
        if (state[x][y] != 0 && board[x][y] != -7) {
            randomChooseMove(x, y, board, state);
        }
        if(state[x][y] != 0 && board[x][y] == -7){
            randomChooseCannon(x,y,board,state);
        }
        if (state[x][y] == 0) {
            randomChooseTurn(x, y, board, state);
        }

    }
    public static boolean abRandomChooseJudge(int x, int y, int[][] board, int[][] state,int c) {
        boolean r = false;
        int n = 0;
        if (state[x][y] == 0) {
            n = 1;
        }
        if (Math.abs(board[x][y]) != 7) {
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 4; j++) {
                    if (MoveJudge.mj(x, y, i, j, board, state)) {
                        n = 1;
                    }
                }
            }
        }
        if (Math.abs(board[x][y]) == 7) {
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 4; j++) {
                    if (CannonJudge.cj(x, y, i, j, board, state)) {
                        n = 1;
                    }
                }
            }
        }
        if(board[x][y]*c<0){
            n = 0;
        }
        if (n == 1) {
            r = true;
        }
        return r;
    }

    public static void randomChooseTurn(int x, int y, int[][] board, int[][] state) {
        state[x][y] = 1;
    }

    public static void randomChooseMove(int x, int y, int[][] board, int[][] state) {
        int[] v = {0, 1, 2, 3, 4, 5, 6, 7};
        int[] h = {0, 1, 2, 3};
        Random r1 = new Random();
        for (int i = 0; i < 8; i++) {
            int index = r1.nextInt(8);
            int temp = v[index];
            v[index] = v[i];
            v[i] = temp;
        }
        Random r2 = new Random();
        for (int i = 0; i < 4; i++) {
            int index = r2.nextInt(4);
            int temp = h[index];
            h[index] = h[i];
            h[i] = temp;
        }
        define:
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 4; j++) {
                if ((MoveJudge.mj(x, y, v[i], h[j], board, state))) {
                    board[v[i]][h[j]] = board[x][y];
                    board[x][y] = 100;
                    break define;
                }
            }
        }
    }

    public static void randomChooseCannon(int x, int y, int[][] board, int[][] state) {
        int[] v = {0, 1, 2, 3, 4, 5, 6, 7};
        int[] h = {0, 1, 2, 3};
        Random r1 = new Random();
        for (int i = 0; i < 8; i++) {
            int index = r1.nextInt(8);
            int temp = v[index];
            v[index] = v[i];
            v[i] = temp;
        }
        Random r2 = new Random();
        for (int i = 0; i < 4; i++) {
            int index = r2.nextInt(4);
            int temp = h[index];
            h[index] = h[i];
            h[i] = temp;
        }
        define:
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 4; j++) {
                if ((CannonJudge.cj(x, y, v[i], h[j], board, state))) {
                    int k = board[v[i]][h[j]];
                    int s = state[v[i]][h[j]];
                    board[v[i]][h[j]] = board[x][y];
                    state[v[i]][h[j]] = 1;
                    board[x][y] = 100;
                    if (s == 0) {
                        System.out.printf("*被吃掉的棋子是%s\n", Convert.convert(k));
                    }
                    break define;
                }
            }
        }
    }
}
