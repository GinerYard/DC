package Project;
import java.util.ArrayList;

public class EndGame {
    public static void saveManual(ArrayList<int[][]> BL,ArrayList<int[][]> SL){
        System.out.println("是否需要保存棋谱？");
    }
}
