package Project;

import java.util.ArrayList;
import java.util.Scanner;

public class Menu {
    public static void main(String[] args) {
        int round = 0;
        int c = 0;
        Scanner input = new Scanner(System.in);
        int[][] board = new int[8][4];
        int[][] state = new int[8][4];
        int[][] pub = new int[8][4];
        ArrayList<int[][]> BL = new ArrayList<>();
        ArrayList<int[][]> SL = new ArrayList<>();
        Var mode = new Var();
        Var clock = new Var();
        clock.setClock(-1);
        mode.setMode(0);
        int n = 100;
        if (n == 100) {
            System.out.println("欢迎游玩翻棋！");
        }
        do {
            System.out.println("0 开始游戏");
            System.out.println("1 加载棋盘");
            System.out.println("2 用户信息");
            System.out.println("3 排行榜");
            System.out.println("-1 退出游戏");
            System.out.println("10 人机对战");
            n = input.nextInt();
            if (n == 0) {
                Start.StartGame(board, state, pub, mode, BL, SL,round,c);
            }
            if(n==1){
                Start.LoadGame(board,state,pub,mode,BL,SL,round,c);
            }
            if(n==10){
                Start.StartGameAI(board,state,pub,mode,BL,SL,round,c,clock);
            }
            if (n == 2){
                User.showUser(clock);
            }
            if (n == -1) {
                System.exit(0);
            }
        } while (n != -1);
    }
}
